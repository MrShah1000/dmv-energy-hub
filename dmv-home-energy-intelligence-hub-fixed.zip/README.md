# DMV Home Energy Savings + Rebate Calculator (Static)

This is a **static Astro site** optimized for SEO (30 pre-rendered location pages) and Firebase Hosting.

## Prerequisites
- Node.js 18+

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Deploy to Firebase Hosting
```bash
npm run deploy
```

### First-time Firebase setup
```bash
npm i -g firebase-tools
firebase login
firebase init hosting
```

Choose:
- Existing project
- Public directory: `dist`
- Configure as single-page app: **No**
