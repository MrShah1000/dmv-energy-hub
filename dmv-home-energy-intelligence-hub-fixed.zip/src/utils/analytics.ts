
export const trackEvent = (name: string, data?: object) => {
  console.log(`[Event: ${name}]`, data);
  // Implementation for GA4 or Plausible goes here
};
