
export const US_AVG_RATE_PER_KWH = 0.1807;

export const UTILITIES = [
  { id: 'pepco-dc', name: 'Pepco (DC)', rate: 0.165, hike: 0.08, state: 'DC' },
  { id: 'pepco-md', name: 'Pepco (MD)', rate: 0.158, hike: 0.09, state: 'MD' },
  { id: 'bge-md', name: 'BGE (Maryland)', rate: 0.162, hike: 0.07, state: 'MD' },
  { id: 'dominion-va', name: 'Dominion Energy (VA)', rate: 0.142, hike: 0.05, state: 'VA' },
  { id: 'wash-gas-dc', name: 'Washington Gas (DC)', rate: 0.12, hike: 0.12, state: 'DC' }
];

export const SEO_PAGES = [
  { slug: 'fairfax-county-va-energy-savings', location: 'Fairfax County, VA' },
  { slug: 'montgomery-county-md-energy-savings', location: 'Montgomery County, MD' },
  { slug: 'prince-georges-county-md-energy-savings', location: 'Prince George\'s County, MD' },
  { slug: 'arlington-va-energy-savings', location: 'Arlington, VA' },
  { slug: 'loudoun-county-va-energy-savings', location: 'Loudoun County, VA' },
  { slug: 'alexandria-va-energy-savings', location: 'Alexandria, VA' },
  { slug: 'baltimore-city-md-energy-savings', location: 'Baltimore City, MD' },
  { slug: 'howard-county-md-energy-savings', location: 'Howard County, MD' },
  { slug: 'anne-arundel-county-md-energy-savings', location: 'Anne Arundel County, MD' },
  { slug: 'ward-1-dc-energy-savings', location: 'Ward 1, DC' },
  { slug: 'ward-2-dc-energy-savings', location: 'Ward 2, DC' },
  { slug: 'ward-3-dc-energy-savings', location: 'Ward 3, DC' },
  { slug: 'ward-4-dc-energy-savings', location: 'Ward 4, DC' },
  { slug: 'ward-5-dc-energy-savings', location: 'Ward 5, DC' },
  { slug: 'ward-6-dc-energy-savings', location: 'Ward 6, DC' },
  { slug: 'ward-7-dc-energy-savings', location: 'Ward 7, DC' },
  { slug: 'ward-8-dc-energy-savings', location: 'Ward 8, DC' },
  { slug: 'frederick-county-md-energy-savings', location: 'Frederick County, MD' },
  { slug: 'prince-william-county-va-energy-savings', location: 'Prince William County, VA' },
  { slug: 'stafford-county-va-energy-savings', location: 'Stafford County, VA' },
  { slug: 'henrico-county-va-energy-savings', location: 'Henrico County, VA' },
  { slug: 'chesterfield-county-va-energy-savings', location: 'Chesterfield County, VA' },
  { slug: 'richmond-city-va-energy-savings', location: 'Richmond City, VA' },
  { slug: 'virginia-beach-va-energy-savings', location: 'Virginia Beach, VA' },
  { slug: 'chesapeake-va-energy-savings', location: 'Chesapeake, VA' },
  { slug: 'norfolk-va-energy-savings', location: 'Norfolk, VA' },
  { slug: 'spotsylvania-va-energy-savings', location: 'Spotsylvania, VA' },
  { slug: 'charles-county-md-energy-savings', location: 'Charles County, MD' },
  { slug: 'carroll-county-md-energy-savings', location: 'Carroll County, MD' },
  { slug: 'rockville-md-energy-savings', location: 'Rockville, MD' }
];
