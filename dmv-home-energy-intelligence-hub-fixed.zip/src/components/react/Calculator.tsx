import React, { useMemo, useState } from 'react';
import { UTILITIES, US_AVG_RATE_PER_KWH } from '../../data/constants';
import { trackEvent } from '../../utils/analytics';

type OwnOrRent = 'own' | 'rent';
type HeatingType = 'electric' | 'gas' | 'heat_pump';

export default function Calculator() {
  const [bill, setBill] = useState(150);
  const [utilityId, setUtilityId] = useState(UTILITIES[0].id);
  const [ownOrRent, setOwnOrRent] = useState<OwnOrRent>('own');
  const [heatingType, setHeatingType] = useState<HeatingType>('electric');

  const [rateOverride, setRateOverride] = useState<string>(''); // dollars per kWh
  const [showResults, setShowResults] = useState(false);

  const selectedUtility = useMemo(
    () => UTILITIES.find(u => u.id === utilityId) ?? UTILITIES[0],
    [utilityId]
  );

  const rate = useMemo(() => {
    const parsed = Number(rateOverride);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : selectedUtility.rate;
  }, [rateOverride, selectedUtility.rate]);

  const results = useMemo(() => {
    const monthlyKWh = bill / rate;
    const annualSpend = bill * 12;

    // Savings ranges (deliberately conservative + transparent)
    const insulationRange = ownOrRent === 'own'
      ? [annualSpend * 0.08, annualSpend * 0.18]
      : [annualSpend * 0.02, annualSpend * 0.06];

    const thermostatRange = [annualSpend * 0.01, annualSpend * 0.07];

    // Heat pump impact only modeled for homeowners; simplified.
    const heatPumpRange =
      ownOrRent === 'own' && (heatingType === 'electric' || heatingType === 'heat_pump')
        ? [annualSpend * 0.05, annualSpend * 0.15]
        : [0, 0];

    const totalLow = insulationRange[0] + thermostatRange[0] + heatPumpRange[0];
    const totalHigh = insulationRange[1] + thermostatRange[1] + heatPumpRange[1];

    // Cost ranges (rough national ballpark; varies by home & region)
    const insulationCost = ownOrRent === 'own' ? [1500, 4500] : [0, 0];
    const thermostatCost = [150, 300];
    const heatPumpCost =
      ownOrRent === 'own' && (heatingType === 'electric' || heatingType === 'heat_pump')
        ? [2500, 7000]
        : [0, 0];

    const costLow = insulationCost[0] + thermostatCost[0] + heatPumpCost[0];
    const costHigh = insulationCost[1] + thermostatCost[1] + heatPumpCost[1];

    const paybackLow = totalHigh > 0 ? (costLow / totalHigh) : null; // best case
    const paybackHigh = totalLow > 0 ? (costHigh / totalLow) : null; // worst case

    // Bill pressure score: compare local rate vs US average (simple, explainable)
    const pressureRatio = rate / US_AVG_RATE_PER_KWH;
    const billFactor = Math.min(1.5, bill / 200); // higher bills => higher sensitivity
    const score = Math.max(0, Math.min(100, Math.round((pressureRatio * 60 + billFactor * 40) )));

    return {
      monthlyKWh,
      annualSpend,
      totalLow,
      totalHigh,
      paybackLow,
      paybackHigh,
      score,
      ranges: {
        insulation: insulationRange,
        thermostat: thermostatRange,
        heatPump: heatPumpRange,
      },
      cost: { costLow, costHigh },
    };
  }, [bill, rate, ownOrRent, heatingType]);

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    setShowResults(true);
    trackEvent('calc_submit', {
      utility: selectedUtility.name,
      bill,
      ownOrRent,
      heatingType,
      rateUsed: rate,
    });
    // Scroll into view on small screens
    setTimeout(() => document.getElementById('results')?.scrollIntoView({ behavior: 'smooth' }), 50);
  };

  const money = (n: number) =>
    n.toLocaleString(undefined, { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });

  const years = (n: number | null) =>
    n === null ? '—' : `${n.toFixed(1)} yrs`;

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 md:p-8">
      <form onSubmit={handleCalculate} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Utility provider</label>
            <select
              value={utilityId}
              onChange={(e) => setUtilityId(e.target.value)}
              className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            >
              {UTILITIES.map((u) => (
                <option key={u.id} value={u.id}>{u.name}</option>
              ))}
            </select>
            <p className="mt-2 text-xs text-slate-500">
              Default rate baseline: <strong>{(selectedUtility.rate * 100).toFixed(1)}¢/kWh</strong> (editable).
            </p>
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Average monthly electric bill: <span className="text-blue-600">{money(bill)}</span>
            </label>
            <input
              type="range"
              min="50"
              max="800"
              step="10"
              value={bill}
              onChange={(e) => setBill(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <div className="mt-3 flex items-center gap-3">
              <label className="text-xs text-slate-500">Override rate ($/kWh)</label>
              <input
                inputMode="decimal"
                placeholder={String(selectedUtility.rate)}
                value={rateOverride}
                onChange={(e) => setRateOverride(e.target.value)}
                className="w-40 px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Ownership</label>
            <div className="flex bg-slate-100 p-1 rounded-lg">
              <button
                type="button"
                className={`flex-1 py-2 text-sm font-medium rounded-md transition ${
                  ownOrRent === 'own' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'
                }`}
                onClick={() => setOwnOrRent('own')}
              >Own</button>
              <button
                type="button"
                className={`flex-1 py-2 text-sm font-medium rounded-md transition ${
                  ownOrRent === 'rent' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'
                }`}
                onClick={() => setOwnOrRent('rent')}
              >Rent</button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Heating type</label>
            <select
              value={heatingType}
              onChange={(e) => setHeatingType(e.target.value as HeatingType)}
              className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            >
              <option value="electric">Electric resistance</option>
              <option value="heat_pump">Heat pump</option>
              <option value="gas">Gas furnace / boiler</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-blue-100"
            >
              Calculate savings
            </button>
          </div>
        </div>
      </form>

      {showResults && (
        <div id="results" className="mt-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <h3 className="text-2xl font-bold mb-6 text-slate-900">Your results (estimates)</h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
              <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">Estimated usage</p>
              <p className="text-2xl font-bold text-slate-900">{Math.round(results.monthlyKWh)} <span className="text-sm font-normal">kWh/mo</span></p>
            </div>

            <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
              <p className="text-xs text-blue-500 uppercase font-bold tracking-wider mb-1">Bill pressure score</p>
              <p className="text-2xl font-bold text-blue-700">{results.score}<span className="text-sm font-normal">/100</span></p>
              <p className="text-xs text-slate-600 mt-1">Based on your bill + rate vs US average.</p>
            </div>

            <div className="bg-green-50 p-4 rounded-xl border border-green-100">
              <p className="text-xs text-green-500 uppercase font-bold tracking-wider mb-1">Annual savings range</p>
              <p className="text-2xl font-bold text-green-700">{money(results.totalLow)}–{money(results.totalHigh)}</p>
            </div>
          </div>

          <div className="mt-6 bg-white border border-slate-200 rounded-xl p-4 text-sm text-slate-700">
            <div className="font-semibold mb-2">Payback (rough range)</div>
            <div className="flex flex-wrap gap-3">
              <span className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg">
                Best case: <strong>{years(results.paybackLow)}</strong>
              </span>
              <span className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg">
                Worst case: <strong>{years(results.paybackHigh)}</strong>
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Costs and savings vary widely by home. Use this as a starting point, not a guarantee.
            </p>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="font-semibold mb-1">Insulation + air sealing</div>
              <div>{money(results.ranges.insulation[0])}–{money(results.ranges.insulation[1])}/yr</div>
            </div>
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="font-semibold mb-1">Thermostat + controls</div>
              <div>{money(results.ranges.thermostat[0])}–{money(results.ranges.thermostat[1])}/yr</div>
            </div>
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="font-semibold mb-1">Heat pump impact</div>
              <div>{money(results.ranges.heatPump[0])}–{money(results.ranges.heatPump[1])}/yr</div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-700">
            <strong>Next step:</strong> check your utility’s rebate portal for insulation/HVAC/thermostat programs. Always confirm eligibility.
          </div>
        </div>
      )}
    </div>
  );
}
