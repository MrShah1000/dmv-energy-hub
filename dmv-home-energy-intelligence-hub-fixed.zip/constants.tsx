
import { UtilityData } from './types';

export const DMV_DATA: Record<string, UtilityData> = {
  'DC': {
    state: 'DC',
    ratePerKWh: 0.2319,
    avgHike: 0.041,
    utilities: ['Pepco', 'Washington Gas']
  },
  'MD': {
    state: 'MD',
    ratePerKWh: 0.1987,
    avgHike: 0.059,
    utilities: ['BGE', 'Pepco', 'Delmarva Power', 'Potomac Edison']
  },
  'VA': {
    state: 'VA',
    ratePerKWh: 0.1601,
    avgHike: 0.035,
    utilities: ['Dominion Energy', 'Appalachian Power', 'Washington Gas']
  }
};

export const ZIP_MAPPING: Record<string, string> = {
  '200': 'DC', // Simplified ZIP prefix mapping
  '206': 'MD',
  '207': 'MD',
  '208': 'MD',
  '209': 'MD',
  '210': 'MD',
  '211': 'MD',
  '212': 'MD',
  '201': 'VA',
  '220': 'VA',
  '221': 'VA',
  '222': 'VA',
  '223': 'VA'
};

export const SEO_SLUGS = [
  "fairfax-county-va-energy-rebates",
  "montgomery-county-md-heat-pump",
  "ward-3-dc-utility-audit",
  "loudoun-county-va-energy-savings",
  "prince-georges-county-md-rebates",
  "arlington-county-va-audit",
  "baltimore-county-md-energy",
  "alexandria-city-va-rebates",
  "howard-county-md-savings",
  "ward-2-dc-rebates"
];
