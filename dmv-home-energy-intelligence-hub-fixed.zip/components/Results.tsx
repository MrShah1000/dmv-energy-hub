
import React from 'react';
import { CalculationResult, UserInput } from '../types';

interface Props {
  results: CalculationResult;
  inputs: UserInput;
}

const Results: React.FC<Props> = ({ results, inputs }) => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-sm text-slate-500 font-medium">Monthly Usage</p>
          <p className="text-3xl font-bold text-slate-900">{Math.round(results.monthlyKWh)} <span className="text-lg">kWh</span></p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-sm text-slate-500 font-medium">PUC Exposure Score</p>
          <div className="flex items-center space-x-2">
            <p className={`text-3xl font-bold ${results.exposureScore > 5 ? 'text-red-600' : 'text-amber-500'}`}>{results.exposureScore}/10</p>
            <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-bold">High Risk</span>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-sm text-slate-500 font-medium">Annual Savings Est.</p>
          <p className="text-3xl font-bold text-green-600">${Math.round(results.savings.insulation + results.savings.thermostat + results.savings.heatPump)}</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-sm text-slate-500 font-medium">Payback Period</p>
          <p className="text-3xl font-bold text-slate-900">{results.paybackYears} <span className="text-lg">Years</span></p>
        </div>
      </div>

      <div className="bg-red-50 border border-red-100 p-6 rounded-2xl">
        <h3 className="text-red-800 font-bold text-lg mb-2 flex items-center">
          <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
          Reliability Risk Disclosure
        </h3>
        <p className="text-red-700 text-sm mb-4">
          Your reliability hedge value is estimated at <strong>${results.reliabilityHedgeValue}</strong>. Local DMV grids are facing a 40-month lead time on critical infrastructure. "Intermittent solar" acts as a reliability-decreasing parasite without storage.
        </p>
        <div className="flex flex-wrap gap-2">
          <span className="bg-white border border-red-200 text-red-600 text-[10px] uppercase font-bold px-2 py-1 rounded">Baseload Fragility</span>
          <span className="bg-white border border-red-200 text-red-600 text-[10px] uppercase font-bold px-2 py-1 rounded">Regulatory Riders</span>
        </div>
      </div>

      <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
        <h3 className="font-bold text-xl mb-6">Savings Breakdown (DMV 2026 Rates)</h3>
        <div className="space-y-6">
          <div className="flex justify-between items-center pb-4 border-b border-slate-100">
            <div>
              <h4 className="font-semibold text-slate-800">Duct Sealing & Insulation</h4>
              <p className="text-xs text-slate-500">15% Bill Reduction | EmPOWER MD Eligible</p>
            </div>
            <p className="font-bold text-green-600">+${Math.round(results.savings.insulation)}/yr</p>
          </div>
          <div className="flex justify-between items-center pb-4 border-b border-slate-100">
            <div>
              <h4 className="font-semibold text-slate-800">Smart Thermostat (HVAC Optimization)</h4>
              <p className="text-xs text-slate-500">8% Efficiency Gain | Utility Rebate Path</p>
            </div>
            <p className="font-bold text-green-600">+${Math.round(results.savings.thermostat)}/yr</p>
          </div>
          {results.savings.heatPump > 0 && (
            <div className="flex justify-between items-center pb-4 border-b border-slate-100">
              <div>
                <h4 className="font-semibold text-slate-800">High-Efficiency Heat Pump</h4>
                <p className="text-xs text-slate-500">45Y & 48E Commercial Credits apply</p>
              </div>
              <p className="font-bold text-green-600">+${Math.round(results.savings.heatPump)}/yr</p>
            </div>
          )}
        </div>
        <p className="mt-6 text-[11px] text-slate-400 italic">
          Disclaimer: Tool results are for informational purposes only. FEOC supply chain compliance may impact actual rebate payouts.
        </p>
      </div>
    </div>
  );
};

export default Results;
