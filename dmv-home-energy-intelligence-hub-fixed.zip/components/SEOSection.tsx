
import React from 'react';
import { Link } from 'react-router-dom';
import { SEO_SLUGS } from '../constants';

const SEOSection: React.FC = () => {
  return (
    <div className="border-t border-slate-200 pt-12">
      <h3 className="text-2xl font-bold text-slate-900 mb-6">Regional Savings Directories</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {SEO_SLUGS.map((slug) => (
          <Link 
            key={slug} 
            to={`/${slug}`} 
            className="text-sm text-blue-600 hover:underline bg-blue-50/50 px-4 py-2 rounded-lg border border-transparent hover:border-blue-200 transition"
          >
            {slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
          </Link>
        ))}
      </div>
      <div className="mt-8 p-6 bg-slate-900 rounded-xl text-white">
        <h4 className="font-bold mb-2">Fighting the $34B Rate Hike Wave</h4>
        <p className="text-sm text-slate-300">
          Our county-specific data feeds directly from the latest Public Utility Commission (PUC) rate cases. Whether you are in Fairfax, Montgomery, or DC Wards, our intelligence helps you navigate the human flourishing impacts of energy policy.
        </p>
      </div>
    </div>
  );
};

export default SEOSection;
