
import React, { useState } from 'react';
import { UserInput } from '../types';

interface Props {
  onCalculate: (data: UserInput) => void;
}

const Calculator: React.FC<Props> = ({ onCalculate }) => {
  const [formData, setFormData] = useState<UserInput>({
    zip: '',
    monthlyBill: 150,
    ownOrRent: 'own',
    heatingType: 'electric',
    evOwnership: 'no'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.zip.length < 5) return alert("Please enter a valid 5-digit ZIP.");
    onCalculate(formData);
    document.getElementById('results')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 text-left">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">ZIP Code</label>
          <input 
            type="text" 
            placeholder="e.g. 22102"
            maxLength={5}
            required
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={formData.zip}
            onChange={(e) => setFormData({...formData, zip: e.target.value})}
          />
        </div>
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Average Monthly Bill: <span className="text-blue-600">${formData.monthlyBill}</span>
          </label>
          <input 
            type="range" 
            min="10" 
            max="1000" 
            step="10"
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            value={formData.monthlyBill}
            onChange={(e) => setFormData({...formData, monthlyBill: parseInt(e.target.value)})}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Status</label>
          <div className="flex bg-slate-100 p-1 rounded-lg">
            <button 
              type="button"
              className={`flex-1 py-2 text-sm font-medium rounded-md transition ${formData.ownOrRent === 'own' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}
              onClick={() => setFormData({...formData, ownOrRent: 'own'})}
            >Own</button>
            <button 
              type="button"
              className={`flex-1 py-2 text-sm font-medium rounded-md transition ${formData.ownOrRent === 'rent' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}
              onClick={() => setFormData({...formData, ownOrRent: 'rent'})}
            >Rent</button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Heating Type</label>
          <div className="flex bg-slate-100 p-1 rounded-lg">
            <button 
              type="button"
              className={`flex-1 py-2 text-sm font-medium rounded-md transition ${formData.heatingType === 'electric' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}
              onClick={() => setFormData({...formData, heatingType: 'electric'})}
            >Electric</button>
            <button 
              type="button"
              className={`flex-1 py-2 text-sm font-medium rounded-md transition ${formData.heatingType === 'gas' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}
              onClick={() => setFormData({...formData, heatingType: 'gas'})}
            >Gas</button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">EV Status</label>
          <select 
            className="w-full px-4 py-2 border border-slate-300 rounded-lg text-sm bg-white"
            value={formData.evOwnership}
            onChange={(e) => setFormData({...formData, evOwnership: e.target.value as any})}
          >
            <option value="no">No EV</option>
            <option value="hybrid">Plug-in Hybrid</option>
            <option value="yes">Full EV</option>
          </select>
        </div>
      </div>

      <button 
        type="submit"
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-200 transition-all transform hover:-translate-y-1"
      >
        Run 2026 Energy Audit
      </button>
    </form>
  );
};

export default Calculator;
