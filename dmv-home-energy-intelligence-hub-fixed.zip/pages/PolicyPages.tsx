
import React from 'react';

const PageLayout: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="max-w-4xl mx-auto py-16 px-4">
    <h1 className="text-4xl font-bold mb-8">{title}</h1>
    <div className="prose prose-slate max-w-none">
      {children}
    </div>
  </div>
);

export const PrivacyPage: React.FC = () => (
  <PageLayout title="Privacy Policy">
    <p>Effective Date: January 2026</p>
    <p>We take your privacy seriously. This site does not store personal energy data. Zip codes and bill estimates are processed in-browser.</p>
    <h3 className="font-bold mt-6">CCPA/GDPR Compliance</h3>
    <p>We do not sell data to third parties. We use cookies only for anonymous analytics and display ad serving via Google AdSense.</p>
  </PageLayout>
);

export const AboutPage: React.FC = () => (
  <PageLayout title="About the Human Flourishing Framework">
    <p>The DMV Energy Intelligence Hub is built on the philosophy that energy is the lifeblood of human flourishing. We believe in providing homeowners and businesses with raw, unvarnished data about the true costs of energy transitions.</p>
    <h3 className="font-bold mt-6">Alex Epstein Impact Framework</h3>
    <p>We analyze energy not just by cost, but by its ability to provide reliable, scalable, and affordable power. We highlight the risks of intermittent sources and the necessity of firm baseload power for regional stability.</p>
  </PageLayout>
);

export const ContactPage: React.FC = () => (
  <PageLayout title="Contact Us">
    <p>For inquiries regarding rate audit methodologies or media requests:</p>
    <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 mt-6">
      <p className="font-bold">Email:</p>
      <p>intel@dmvenergyhub.example.com</p>
      <p className="mt-4 font-bold">PUC Advocacy Hub:</p>
      <p>Suite 400, NW Washington D.C.</p>
    </div>
  </PageLayout>
);
