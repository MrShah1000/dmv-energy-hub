
import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import Calculator from './components/Calculator';
import Results from './components/Results';
import SEOSection from './components/SEOSection';
import { PrivacyPage, AboutPage, ContactPage } from './pages/PolicyPages';
import { UserInput, CalculationResult } from './types';
import { DMV_DATA, ZIP_MAPPING } from './constants';

const App: React.FC = () => {
  const [inputs, setInputs] = useState<UserInput | null>(null);
  const [results, setResults] = useState<CalculationResult | null>(null);
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  const handleCalculate = (data: UserInput) => {
    const zipPrefix = data.zip.substring(0, 3);
    const stateKey = ZIP_MAPPING[zipPrefix] || 'VA'; // Default to VA if unknown
    const stateData = DMV_DATA[stateKey];

    const monthlyKWh = data.monthlyBill / stateData.ratePerKWh;
    const annualSpend = data.monthlyBill * 12;
    
    // Logic: Insulation saves 15%, Heat Pump saves 40% if electric, Thermostat 8%
    const insulationSavings = annualSpend * 0.15;
    const thermostatSavings = annualSpend * 0.08;
    const heatPumpSavings = data.heatingType === 'electric' ? annualSpend * 0.35 : 0;

    const totalPotentialSavings = insulationSavings + thermostatSavings + (data.ownOrRent === 'own' ? heatPumpSavings : 0);
    const estimatedCostOfUpgrades = 8000; // Simplified blend
    const payback = totalPotentialSavings > 0 ? estimatedCostOfUpgrades / totalPotentialSavings : 15;

    setInputs(data);
    setResults({
      monthlyKWh,
      annualSpend,
      savings: {
        insulation: insulationSavings,
        heatPump: heatPumpSavings,
        thermostat: thermostatSavings
      },
      paybackYears: parseFloat(payback.toFixed(1)),
      exposureScore: Math.min(10, (stateData.avgHike * 100)),
      reliabilityHedgeValue: (data.evOwnership !== 'no' ? 1200 : 400) // Value of preventing downtime
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="font-bold text-xl text-blue-700 tracking-tight">DMV Energy Intelligence Hub</Link>
          <div className="hidden md:flex space-x-6 text-sm font-medium text-slate-600">
            <Link to="/" className="hover:text-blue-600">Calculator</Link>
            <Link to="/about" className="hover:text-blue-600">About</Link>
            <Link to="/contact" className="hover:text-blue-600">Contact</Link>
          </div>
        </div>
      </nav>

      <main className="flex-grow">
        <Routes>
          <Route path="/" element={
            <>
              <section className="bg-gradient-to-b from-blue-50 to-white py-16 px-4">
                <div className="max-w-4xl mx-auto text-center">
                  <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6">
                    Audit Your Exposure to the <span className="text-red-600">$34B</span> Rate Hike Wave
                  </h1>
                  <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
                    The DMV region is facing record high electricity costs. Use our 2026 intelligence tool to island your finances from grid instability.
                  </p>
                  <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-200">
                    <Calculator onCalculate={handleCalculate} />
                  </div>
                </div>
              </section>

              {results && inputs && (
                <section id="results" className="py-16 px-4 bg-slate-50">
                  <div className="max-w-4xl mx-auto">
                    <Results results={results} inputs={inputs} />
                  </div>
                </section>
              )}

              <section className="py-16 px-4">
                <div className="max-w-4xl mx-auto">
                  <SEOSection />
                </div>
              </section>
            </>
          } />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/:slug" element={
             <section className="py-16 px-4">
               <div className="max-w-4xl mx-auto">
                 <h2 className="text-3xl font-bold mb-6">Localized Energy Insights</h2>
                 <p className="text-lg text-slate-600 mb-8">
                    This specialized page provides hyper-localized data for DMV residents fighting back against skyrocketing utility rates.
                 </p>
                 <Calculator onCalculate={handleCalculate} />
                 <div className="mt-12 bg-blue-50 p-6 rounded-xl border border-blue-100">
                    <h3 className="font-bold text-lg text-blue-800 mb-2">Did you know?</h3>
                    <p className="text-blue-700">The DMV region residential rate increase of 7.4% outpaces the national average. Homeowners in this county are eligible for specific EmPOWER and OBBBA tax credits.</p>
                 </div>
               </div>
             </section>
          } />
        </Routes>
      </main>

      {/* AdSense Static Placeholder */}
      <div className="w-full bg-slate-100 py-4 flex justify-center overflow-hidden border-y border-slate-200">
        <div className="w-[728px] h-[90px] bg-slate-200 flex items-center justify-center text-slate-400 text-xs border border-dashed border-slate-300">
           Advertisement
        </div>
      </div>

      <footer className="bg-slate-900 text-slate-400 py-12 px-4">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <h3 className="text-white font-bold mb-4">DMV Energy Hub</h3>
            <p className="text-sm">Empowering homeowners with data to navigate the energy transition safely and affordably.</p>
          </div>
          <div>
            <h3 className="text-white font-bold mb-4">Quick Links</h3>
            <ul className="text-sm space-y-2">
              <li><Link to="/about" className="hover:text-white">About the Framework</Link></li>
              <li><Link to="/privacy" className="hover:text-white">Privacy Policy</Link></li>
              <li><Link to="/contact" className="hover:text-white">Contact Us</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-white font-bold mb-4">Legal</h3>
            <p className="text-xs">
              &copy; 2025 DMV Energy Intelligence Hub. Calculations are estimates and non-promissory. Utility rates based on Jan 2026 projections.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
