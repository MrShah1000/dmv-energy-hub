
export type Jurisdiction = 'DC' | 'MD' | 'VA';

export interface UtilityData {
  state: Jurisdiction;
  ratePerKWh: number;
  avgHike: number;
  utilities: string[];
}

export interface CalculationResult {
  monthlyKWh: number;
  annualSpend: number;
  savings: {
    insulation: number;
    heatPump: number;
    thermostat: number;
  };
  paybackYears: number;
  exposureScore: number;
  reliabilityHedgeValue: number;
}

export interface UserInput {
  zip: string;
  monthlyBill: number;
  ownOrRent: 'own' | 'rent';
  heatingType: 'electric' | 'gas';
  evOwnership: 'yes' | 'hybrid' | 'no';
}
